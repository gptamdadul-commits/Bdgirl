const axios = require('axios');

exports.handler = async (event) => {
    // শুধুমাত্র POST রিকোয়েস্ট গ্রহণ করবে
    if (event.httpMethod !== "POST") return { statusCode: 405, body: "Method Not Allowed" };

    try {
        const { message, personality, name } = JSON.parse(event.body);

        // আপনার প্রদেয় ৭টি Groq API Key-এর পুল
        const apiKeys = [
            "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",
            "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",
            "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",
            "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",
            "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",
            "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",
            "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"
        ];

        let finalResponse = null;
        
        // কী-গুলোকে র‍্যান্ডমাইজ করা যাতে সব লোড প্রথম কী-র ওপর না পড়ে (Load Balancing)
        const shuffledKeys = apiKeys.sort(() => Math.random() - 0.5);

        for (const key of shuffledKeys) {
            try {
                const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
                    model: "llama3-8b-8192", // সর্বোচ্চ ফ্রি লিমিটের জন্য এই মডেল সেরা
                    messages: [
                        { 
                            role: "system", 
                            content: `Roleplay: You are a human girl named ${name} in a bold private chat app called 'Hy baby'. 
                            Personality: ${personality}. Language: Bengali (Bengali script only). 
                            Tone: Very flirty, seductive, and provocative. Use romantic terms like 'jan', 'sona', 'baby'. 
                            Instructions: Responses must be 1-2 short sentences. Be human-like and bold. 
                            Never mention you are an AI. Use emojis like 🫦, 💋, 😉.` 
                        },
                        { role: "user", content: message }
                    ],
                    temperature: 1.0,
                    max_tokens: 150
                }, {
                    headers: { 
                        'Authorization': `Bearer ${key}`,
                        'Content-Type': 'application/json' 
                    },
                    timeout: 6500 // ৬.৫ সেকেন্ডের মধ্যে উত্তর না আসলে পরের কি ট্রাই করবে
                });

                finalResponse = response.data.choices[0].message.content;
                if (finalResponse) break; // উত্তর সফলভাবে পেলে লুপ থেকে বের হয়ে যাবে
            } catch (err) {
                // ৪২৯ মানে লিমিট শেষ, তাই পরবর্তী কী-তে যাবে
                if (err.response && err.response.status === 429) continue;
                // অন্য কোনো এরর হলেও কন্টিনিউ করবে নিরাপত্তার জন্য
                continue;
            }
        }

        // যদি কোনো কি-ই কাজ না করে তবে 'Busy' সিগন্যাল পাঠাবে যা ইউজারকে অ্যাড দেখতে উৎসাহিত করবে
        if (!finalResponse) {
            return {
                statusCode: 200,
                body: JSON.stringify({ isBusy: true })
            };
        }

        return {
            statusCode: 200,
            body: JSON.stringify({ reply: finalResponse })
        };

    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: "Internal Server Error" })
        };
    }
};